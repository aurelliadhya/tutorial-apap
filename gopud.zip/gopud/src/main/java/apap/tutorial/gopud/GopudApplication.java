package apap.tutorial.gopud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GopudApplication {

	public static void main(String[] args) {
		SpringApplication.run(GopudApplication.class, args);
	}

}
