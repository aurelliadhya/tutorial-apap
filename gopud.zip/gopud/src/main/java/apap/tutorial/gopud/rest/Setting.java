package apap.tutorial.gopud.rest;

public class Setting {
    final public static String restoranUrl = "https://b49cddea-9d8c-42df-8871-f22b4b81816b.mock.pstmn.io";
}
